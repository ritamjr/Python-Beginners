'''Using input function take two number and then swap the number '''

a = int(input("Enter the 1st Number: "))
b = int(input("Enter the 2nd Number: "))

print("Numbers before Swapping")
print("1st=",a," 2nd= ",b)

a,b = b,a
print("Numbers after Swapping")
print("1st=",a," 2nd=",b)