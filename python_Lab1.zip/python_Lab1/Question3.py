''' Write a Program to Convert Kilometers to Miles '''

km = float(input("Enter the Kilometer: "))

miles = km * 0.621371

print("Miles= ",miles)
