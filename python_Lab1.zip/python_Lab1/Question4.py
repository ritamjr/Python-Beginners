''' Find the Simple Interest on Rs. 200 for 5 years at 5% per year.'''

p = 200
t =5
r= 0.05

SI = p*r*t
print("Simple Interest: ",SI)