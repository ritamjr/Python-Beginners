'''Using input() function take one number from the user and using ternary operators check whether the number is even or odd '''

num = int(input("Enter a Number: "))
print("Even" if num % 2 == 0 else "Odd")