# Write a Python program to find the number of times 4 appears in the tuple.

data = input("Enter the elements of the tuple separated by spaces: ")
tup = tuple(int(x) for x in data.split())

counts = {}
for num in tup:
    counts[num] = counts.get(num, 0) + 1
four = [num for num, count in counts.items() if count == 4]
if four:
    print("Numbers appearing 4 times:", four)
else:
    print("No number appears 4 times.")
