# Write a Python program and calculate the mean of the below dictionary.
# test_dict = {"A" : 6, "B" : 9, "C" : 5, "D" : 7, "E" : 4}
# Output: 6.2

test_dict = {"A": 6, "B": 9, "C": 5, "D": 7, "E": 4}
# total = sum(test_dict.values())
mean = sum(test_dict.values()) / len(test_dict)
print(test_dict)
print("Mean:", mean)
