# Write a Python program to sum all the items in a list.

l=[]
n=int(input("Enter number of items to be inserted: "))

for i in range(n):
    nn=int(input("Enter the numbers: "))
    l.append(nn)

total=sum(l)

print("Sum of all numbers: ",total)
