# Write a Python program to split a given list into two parts where the length of the first
# part of the list is given.
# Original list:
# [1, 1, 2, 3, 4, 4, 5, 1]
# Length of the first part of the list: 3
# Splitted the said list into two parts:
# ([1, 1, 2], [3, 4, 4, 5, 1])

user_list = []
n = int(input("Enter the number of elements in the list: "))
print("Enter the elements:")
for i in range(n):
    user_list.append(int(input()))

len_first_part = int(input("Enter the length of the first part of the list: "))
first_part = []
for i in range(len_first_part):
    if i < len(user_list):
        first_part.append(user_list[i])
second_part = []
for i in range(len_first_part, len(user_list)):
    second_part.append(user_list[i])
print("Original list:")
print(user_list)
print("Length of the first part:", len_first_part)
print("Splitted:")
print((first_part, second_part))




# def split_list(lst, length_first_part):
#     first_part= lst[:length_first_part]
#     second_part= lst[length_first_part:]
#     return first_part, second_part
# user_list= input("Enter the list elements use commas: ")
# user_list= [int(x.strip()) for x in user_list.split(",")]
# length_of_first_part= int(input("Enter the length of the first part of the list: "))
# result= split_list(user_list, length_of_first_part)
# print("Original list:")
# print(user_list)
# print("Length of the first part of the list:", length_of_first_part)
# print("Splitted the said list into two parts:")
# print(result)
