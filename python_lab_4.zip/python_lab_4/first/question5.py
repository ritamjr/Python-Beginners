# Write a Python program to traverse a given list in reverse order, and print the
# elements with the original index.
# Original list:
# ['red', 'green', 'white', 'black']
# Traverse the said list in reverse order:
# black
# white
# green
# red



user= []
n=int(input("Enter the number of elements in the list: "))
print("Enter the elements:")
for i in range(n):
    user.append(input())
print("Traversing list in reverse order:")
for i in range(len(user) - 1, -1, -1):
    print(i,":", list[i])
