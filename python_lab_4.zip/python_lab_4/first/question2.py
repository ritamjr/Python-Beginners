# Write a Python program to get the largest and smallest number from a list without
# builtin functions.

l=[]
n=int(input("Enter number of items to be inserted: "))

for i in range(n):
    nn=int(input("Enter the numbers: "))
    l.append(nn)
a=l[0]
b=l[0]
for i in l:
    if i>a:
        a=i
    else:
        b=i

print("Smallest: ",b)
print("Greatest: ",a)