# Write a Python program to find duplicate values from a list and display those.

l=[]
n=int(input("Enter number of items to be inserted: "))

for i in range(n):
    nn=int(input("Enter the numbers: "))
    l.append(nn)
dup=[]
for i in l:
    if l.count(i)>1 and i not in dup:
        dup.append(i)

if dup:
    print("Duplicates: ",dup)
else:
    print("No Duplicates...")