# Write a Python Count vowels in a string
# input= “Welcome to Python Assignment”
# Output: Total vowels are: 8



input_str = "Welcome to Python Assignment"
v = "aeiouAEIOU"
c = 0
for i in input_str:
    if i in v:
        c += 1
print("Vowels:", c)
