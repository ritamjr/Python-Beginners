# Write a Python program to count Uppercase, Lowercase, special
# character and numeric values in a given string
# Input = “Hell0 W0rld ! 123 * # welcome to pYtHoN”
# Output:
# UpperCase : 5
# LowerCase : 18
# NumberCase : 5
# SpecialCase : 11


s = "Hell0 W0rld ! 123 * # welcome to pYtHoN"
uppercase=0
lowercase=0
numbers=0
special = 0
for char in s:
    if char.isupper():
        uppercase += 1
    elif char.islower():
        lowercase += 1
    elif char.isdigit():
        numbers += 1
    elif not char.isspace():
        special += 1
print("UpperCase :", uppercase)
print("LowerCase :", lowercase)
print("NumberCase :", numbers)
print("SpecialCase :", special)
