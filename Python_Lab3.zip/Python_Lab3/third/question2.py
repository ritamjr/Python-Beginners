# Write a Python program to remove duplicate characters of a given
# string.
# Input = “String and String Function”
# Output: String and Function

s = "String and String Function"
w = s.split()
unique = []
for i in w:
    if i not in unique:
        unique.append(i)
new = " ".join(unique)
print("Output:", new)
