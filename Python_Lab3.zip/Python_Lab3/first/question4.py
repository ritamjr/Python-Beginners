# Accept a name from the user and display that in lower case using lower()
# function

def lower():
    str = input("Enter a Name: ")
    low = str.lower()
    print(low)
lower()