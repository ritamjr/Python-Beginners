# Declare a square() function with one parameter.Then call the function and pass
# one number and display the square of that number .

def square(a):
    if a!=0:
        return pow(a,2)
    else:
        return "Square of 0 is 0"
num =int(input("Enter a Number: "))
n=square(num)
print(n)