# Declare a div() function with two parameters. Then call the function and pass two
# numbers and display their division.

def div(a,b):
    if b!=0:  
        return a/b
    else:
        return "Divisor shouldn'y be 0"

one= int(input("Enter the Dividend: "))
two=int(input("Enter the Divisor: "))
r = div(one,two)

print(r)
