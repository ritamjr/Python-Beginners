# Write a Python program to reverse words in a string
# String = “Deeptech Python Training”

str = "Deeptech Python Training"
rev = ' '.join(str.split()[::-1])
print(rev)
