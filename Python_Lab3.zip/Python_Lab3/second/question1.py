# Write a Python program to count the occurrences of each word in a
# given sentence
# string = “To change the overall look of your document. To change the look
# available in the gallery"

str = "To change the overall look of your document. To change the look available in the gallery"

w =str.lower().split()
c={}
for i in w:
    c[i] = c.get(i, 0) + 1
# print(c)

print("Word occurrences:")
for i, p in c.items():
    print(i ,":", p)
    
# i have used .get to retriev the value associated with the key "i" in the dictionary.
