# Write a Python program to count and display the vowels of a given
# text
# String=”Welcome to python Training”

str = "Welcome to python Training"
v="aeiouAEIOU"
c={}
for i in v:
    c[i] = 0
for i in str:
    if i in v:
        c[i] =c[i]+ 1
print("Vowel Counts:")
for vowel, count in c.items():
    if count > 0:
        print(vowel, ":",count)